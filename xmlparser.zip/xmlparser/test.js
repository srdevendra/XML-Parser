


 var data =   {
        'repo' : {
            'type' : 'git' ,
            'value'  :  'git://github.com/oozcitak/xmlbuilder-js.git'
        }
    }

    objKeys =  Object.keys(data);

    for (key of objKeys) {
           
        keys = Object.keys(data[key]);
    }

    console.log(Object.keys(data));


