var builder = require('xmlbuilder');

const Xml  =  (keyValue, pnrValue) => {

    keyValue = {
        'wsse:Username' : 'INF_MOBILE_IBE1',
        'password' : 'QTCLMd5!'
    }
    pnrValue = {
        'urn1:PNRLocator' : 'REIIXG'
    }
      
    // var  data =  {
    //     xmlbuilder: {
    //         repo: {
         
    //       } 
    //     }
    //   }


    // Keys = Object.keys(keyValue)

    // for(key of Keys) {
    //     data.xmlbuilder.repo[key] = keyValue[key]
    // }

    var  data =  {
        "soapenv:Envelope" : {
            "@xmlns:soapenv": "http://schemas.xmlsoap.org/soap/envelope/",
            "@xmlns:urn":"urn:www.virginaustralia.com:model:schema:utility",
	        "@xmlns:urn1":"urn:www.virginaustralia.com:model:schema:reservation-management",
          
          "soapenv:Header":{
              "wsse:Security":{
                    "@xmlns:wsse":"http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-secext-1.0.xsd",
              },
              "wsse:UsernameToken":{
                //   "wsse:Username":"INF_MOBILE_IBE1",
                //   "wsse:Password":"QTCLMd5!",
              },
          },
          "soapenv:Body":{
            "urn1:GetReservationRQ":{
                "@version":"2.4", 
                "@TransactionType":"Stateless"
            },
            "urn1:PNRLocator":"REIIXG"
        }

        }
      };

    Keys = Object.keys(keyValue)

    for(key of Keys) {        
      data['soapenv:Envelope']['soapenv:Header']["wsse:UsernameToken"][key] = keyValue[key]
    }

    pnrKeys = Object.keys(pnrValue)
    for(pnrKey of pnrKeys) {
        data['soapenv:Envelope']['soapenv:Body'][pnrKey] = pnrValue[pnrKey]
    }

    var xml = builder.create(data).end({ pretty: true });
    return xml;
}

module.exports.Xml = Xml